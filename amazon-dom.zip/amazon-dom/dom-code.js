
document.querySelector('#nav-cart-count').textContent = "99";